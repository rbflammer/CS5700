﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Shapes;

namespace ShapesTesting
{
    [TestClass]
    public class ShapeTester
    {
        [TestMethod]
        public void Shape_TestCreate()
        {
            ShapeFactory sf = new ShapeFactory();

            // Shape s = sf.Create();

        }
    }
}
