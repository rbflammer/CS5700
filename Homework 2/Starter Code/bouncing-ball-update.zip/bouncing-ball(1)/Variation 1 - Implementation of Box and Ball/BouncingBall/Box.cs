﻿namespace BouncingBall
{
    public static class Box
    {
        public static int Width { get; set; }
        public static int Height { get; set; }
        public static string Label { get; set; }
    }
}
